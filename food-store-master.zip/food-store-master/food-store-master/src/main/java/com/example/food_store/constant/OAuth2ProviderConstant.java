package com.example.food_store.constant;

public class OAuth2ProviderConstant {
    public static final String GITHUB = "GITHUB";
    public static final String GOOGLE = "GOOGLE";
}
