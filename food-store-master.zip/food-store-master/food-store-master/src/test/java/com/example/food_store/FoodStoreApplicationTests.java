package com.example.food_store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
